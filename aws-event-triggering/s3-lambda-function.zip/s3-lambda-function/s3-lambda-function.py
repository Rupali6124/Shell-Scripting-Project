import boto3
import json
from urllib.parse import unquote_plus
import os

def lambda_handler(event, context):
    # SNS client
    sns_client = boto3.client('sns')
    
    # Use environment variable for SNS topic ARN
    topic_arn = os.environ.get('SNS_TOPIC_ARN', 'arn:aws:sns:us-east-1:<account-id>:s3-lambda-sns')

    # Loop through all S3 records in case multiple files are uploaded
    for record in event['Records']:
        bucket_name = record['s3']['bucket']['name']
        object_key = unquote_plus(record['s3']['object']['key'])  # decode URL-encoded key

        # Log file upload
        print(f"File '{object_key}' was uploaded to bucket '{bucket_name}'")

        # Send notification via SNS safely
        try:
            sns_client.publish(
                TopicArn=topic_arn,
                Subject='S3 Object Created',
                Message=f"File '{object_key}' was uploaded to bucket '{bucket_name}'"
            )
        except Exception as e:
            print(f"Failed to send SNS notification: {e}")

        # Optional: Trigger another Lambda function
        # lambda_client = boto3.client('lambda')
        # target_function_name = 'my-another-lambda-function'
        # try:
        #     lambda_client.invoke(
        #         FunctionName=target_function_name,
        #         InvocationType='Event',
        #         Payload=json.dumps({'bucket_name': bucket_name, 'object_key': object_key})
        #     )
        # except Exception as e:
        #     print(f"Failed to invoke another Lambda: {e}")

    return {
        'statusCode': 200,
        'body': json.dumps('Lambda function executed successfully')
    }

